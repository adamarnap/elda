<!-- page content -->
          <div class="right_col" role="main">
            <div class="row">
              <div class="col-md-12">
                  <div class="x_content">
                    <div class="col-md-9 col-sm-12 ">
                    </div>
                    <div class="col-md-3 col-sm-12 ">
                  </div>
              </div>
            </div>
          </div>

            <div class="row">
              <div class="col-md-4">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kelas 7</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">7A</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">Kelas 7A</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">7B</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">Kelas 7B</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">7C</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">Kelas 7C</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">7D</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">Kelas 7D</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">7E</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">Kelas 7E</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kelas 8</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">8A</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">8A</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">8B</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">8B</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">8C</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">8C</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">8D</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">8D</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">8E</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">8E</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kelas 9</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">9A</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">9A</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">9B</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">9B</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">9C</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">9C</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">9D</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">9D</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                    <article class="media event">
                      <a class="pull-left date">
                        <p class="day">9E</p>
                      </a>
                      <div class="media-body">
                        <a class="title" href="#">9E</a>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->